document.querySelector("body > div.contenedor > div > div.contenedorFiltros > div > div.col-xs-8").className = "col-xs-7";
const parent = document.querySelector("body > div.contenedor > div > div.contenedorFiltros > div > div.col-xs-4");
parent.className = "col-xs-5";

  var newDiv = document.createElement("div");
  newDiv.className = "col-xs-4";

newDiv.innerHTML = 	`	<!-- Select Zona -->
								<div class="input-group">
									<span class="input-group-addon">Zona</span>
									<select class="form-control" id="ZONA-SELECT" onchange="cambiarZona(this.value)" multiple size="2">	
										<option value="1">Caba</option>
										<option value="2">Norte</option>
										<option value="4">Oeste</option>
										<option value="8">Sur</option>
										<option value="16">FTTH</option>
										<option value="32">Todo</option>
									</select>
								</div>`;

parent.insertBefore(newDiv, parent.firstChild);



    var theSelect = document.querySelector("#SECTOR-SELECT");
    var options = theSelect.getElementsByTagName('OPTION');
    for(var i=0; i<options.length; i++) {
        if(options[i].innerHTML == 'CEOP') {
        	break;
        } else {
        	theSelect.removeChild(options[i]);
            i--; // options have now less element, then decrease i

        }
    }

// realiza el cambio de sector por el de ceop
var elementExists = document.querySelector("#BT-LIST-5f316bcf1d2eef8fbf5a4f4c");
if(elementExists){
encambio();}
// realiza el cambio de sector por el de ceop


// agarra los numeros de los selected del select ce zona 
 qzona = document.querySelector("#ZONA-SELECT");
    let totalselec = 0;
    for (var option of qzona.options)
    {
        if (option.selected) {
            totalselec += Number(option.value);
        }
    }
    console.log("total select:" + totalselec);
    //totalselec es la suma de los selects

chrome.runtime.sendMessage({ 
    message: "get_zona"
}, response => {
    if (response.message === 'success') {
    	console.log("success del send message");
    	var x = `${response.payload}`;
    var x = document.getElementById('ZONA-SELECT').getElementsByTagName('option');
    console.log(x);
    if(x >= 8) {
    	 x = x - 8;
      console.log(x);
     x[3].selected = true;	
    }
        if(x >= 4) {
    	 x = x - 4;
      console.log(x);
     x[2].selected = true;	
    }
            if(x >= 2) {
    	 x = x - 2;
      console.log(x);
     x[1].selected = true;	
    }
            if(x >= 1) {
    	 x = x - 1;
      console.log(x);
     x[0].selected = true;	
    					}
    }
});


qzona.addEventListener('change', () => {
    chrome.runtime.sendMessage({ 
        message: "change_zona",
        payload: totalselec
    }, response => {
        if (response.message === 'success') {
            console.log(`${totalselec}`);

            //aca deberia ir lo que borra las colas
        }
    });
});


function encambio(){
    var changeEvent = document.createEvent("HTMLEvents");
	changeEvent.initEvent("change", true, true);
	document.querySelector("#SECTOR-SELECT").dispatchEvent(changeEvent);
}


